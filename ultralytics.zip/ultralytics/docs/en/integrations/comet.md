---
title: YOLO26 Training Logging with Comet ML
comments: true
description: Learn to simplify the logging of YOLO26 training with Comet. This guide covers installation, setup, real-time insights, and custom logging.
keywords: YOLO26, Comet, Comet ML, logging, machine learning, training, model checkpoints, metrics, installation, configuration, real-time insights, custom logging
---

# Elevating YOLO26 Training: Simplify Your Logging Process with Comet

Logging key training details such as parameters, metrics, image predictions, and model checkpoints is essential in [machine learning](https://www.ultralytics.com/glossary/machine-learning-ml)—it keeps your project transparent, your progress measurable, and your results repeatable.

<p align="center">
  <br>
  <iframe loading="lazy" width="720" height="405" src="https://www.youtube.com/embed/LPodYpvKkvI"
    title="YouTube video player" frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    allowfullscreen>
  </iframe>
  <br>
  <strong>Watch:</strong> How to Use Comet for Ultralytics YOLO Model Training Logs and Metrics 🚀
</p>

[Ultralytics YOLO26](https://www.ultralytics.com) seamlessly integrates with Comet (formerly Comet ML), efficiently capturing and optimizing every aspect of your YOLO26 [object detection](https://www.ultralytics.com/glossary/object-detection) model's training process. In this guide, we'll cover the installation process, Comet setup, real-time insights, custom logging, and offline usage, ensuring that your YOLO26 training is thoroughly documented and fine-tuned for outstanding results.

## Comet

<p align="center">
  <img width="640" src="https://www.comet.com/docs/v2/img/landing/home-hero.svg" alt="Comet ML experiment tracking dashboard">
</p>

[Comet](https://www.comet.com/site/) is a platform for tracking, comparing, explaining, and optimizing machine learning models and experiments. It allows you to log metrics, parameters, media, and more during your model training and monitor your experiments through an aesthetically pleasing web interface. Comet helps data scientists iterate more rapidly, enhances transparency and reproducibility, and aids in the development of production models.

## Harnessing the Power of YOLO26 and Comet

By combining Ultralytics YOLO26 with Comet, you unlock a range of benefits. These include simplified experiment management, real-time insights for quick adjustments, flexible and tailored logging options, and the ability to log experiments offline when internet access is limited. This integration empowers you to make data-driven decisions, analyze performance metrics, and achieve exceptional results.

## Installation

To install the required packages, run:

!!! tip "Installation"

    === "CLI"

        ```bash
        # Install the required packages for YOLO26 and Comet
        pip install ultralytics comet_ml torch torchvision
        ```

## Configuring Comet

After installing the required packages, you'll need to sign up, get a [Comet API Key](https://www.comet.com/signup), and configure it.

!!! tip "Configuring Comet"

    === "CLI"

        ```bash
        # Set your Comet API Key
        export COMET_API_KEY=YOUR_API_KEY
        ```

Then, you can initialize your Comet project. Comet will automatically detect the API key and proceed with the setup.

!!! example "Initialize Comet project"

    === "Python"

        ```python
        import comet_ml

        comet_ml.login(project_name="comet-example-yolo26-coco128")
        ```

If you are using a Google Colab notebook, the code above will prompt you to enter your API key for initialization.

## Usage

Before diving into the usage instructions, be sure to check out the range of [YOLO26 models offered by Ultralytics](../models/yolo26.md). This will help you choose the most appropriate model for your project requirements.

!!! example "Usage"

    === "Python"

        ```python
        from ultralytics import YOLO

        # Load a model
        model = YOLO("yolo26n.pt")

        # Train the model
        results = model.train(
            data="coco8.yaml",
            project="comet-example-yolo26-coco128",
            batch=32,
            save_period=1,
            save_json=True,
            epochs=3,
        )
        ```

After running the training code, Comet will create an experiment in your Comet workspace to track the run automatically. You will then be provided with a link to view the detailed logging of your [YOLO26 model's training](../modes/train.md) process.

Comet automatically logs the following data with no additional configuration: metrics such as mAP and loss, hyperparameters, model checkpoints, interactive confusion matrix, and image [bounding box](https://www.ultralytics.com/glossary/bounding-box) predictions.

## Understanding Your Model's Performance with Comet Visualizations

Let's dive into what you'll see on the Comet dashboard once your YOLO26 model begins training. The dashboard is where all the action happens, presenting a range of automatically logged information through visuals and statistics. Here's a quick tour:

**Experiment Panels**

The experiment panels section of the Comet dashboard organizes and presents the different runs and their metrics, such as segment mask loss, class loss, precision, and [mean average precision](https://www.ultralytics.com/glossary/mean-average-precision-map).

<p align="center">
  <img width="640" src="https://cdn.ul.run/i/1c5db1d4fb62e6c797aa07edb63d5bd1.avif" alt="Comet ML experiment tracking dashboard">
</p>

**Metrics**

In the metrics section, you have the option to examine the metrics in a tabular format as well, which is displayed in a dedicated pane as illustrated here.

<p align="center">
  <img width="640" src="https://cdn.ul.run/i/bafc0048079ac6eb4f75810873cebad7.avif" alt="Comet ML experiment tracking dashboard">
</p>

**Interactive [Confusion Matrix](https://www.ultralytics.com/glossary/confusion-matrix)**

The confusion matrix, found in the Confusion Matrix tab, provides an interactive way to assess the model's classification [accuracy](https://www.ultralytics.com/glossary/accuracy). It details the correct and incorrect predictions, allowing you to understand the model's strengths and weaknesses.

<p align="center">
  <img width="640" src="https://cdn.ul.run/i/3b562147e59c9e850c163417886a8ea8.avif" alt="Comet ML experiment tracking dashboard">
</p>

**System Metrics**

Comet logs system metrics to help identify any bottlenecks in the training process. It includes metrics such as GPU utilization, GPU memory usage, CPU utilization, and RAM usage. These are essential for monitoring the efficiency of resource usage during model training.

<p align="center">
  <img width="640" src="https://cdn.ul.run/i/7182de7672f7dd9f5bb9a52fdd19c265.avif" alt="Comet ML experiment tracking dashboard">
</p>

## Customizing Comet Logging

Comet offers the flexibility to customize its logging behavior by setting environment variables. These configurations allow you to tailor Comet to your specific needs and preferences. The Ultralytics callback reads the following environment variables (set them before training starts):

| Environment Variable                | Default        | Description                                                                                               |
| ----------------------------------- | -------------- | --------------------------------------------------------------------------------------------------------- |
| `COMET_START_ONLINE`                | `1`            | Run the experiment in online (`1`) or offline (`0`) mode.                                                 |
| `COMET_PROJECT_NAME`                | `args.project` | Comet workspace project. Falls back to the YOLO `project` training argument when unset.                   |
| `COMET_MODEL_NAME`                  | `Ultralytics`  | Name registered for the logged model artifact.                                                            |
| `COMET_MAX_IMAGE_PREDICTIONS`       | `100`          | Total number of validation image predictions to log per run.                                              |
| `COMET_EVAL_BATCH_LOGGING_INTERVAL` | `1`            | Log image predictions every Nth validation batch.                                                         |
| `COMET_EVAL_LOG_IMAGE_PREDICTIONS`  | `true`         | Toggle image prediction logging on (`true`) or off (`false`).                                             |
| `COMET_EVAL_LOG_CONFUSION_MATRIX`   | `false`        | Log a confusion matrix on every validation epoch. A final matrix is always logged at end of training.     |
| `COMET_MAX_CONFIDENCE_SCORE`        | `100.0`        | Multiplier applied to detection confidence scores before logging (Comet's UI expects a percentage scale). |
| `COMET_MODE` _(deprecated)_         | `online`       | Legacy alias of `COMET_START_ONLINE` (`"online"` ↔ `1`, `"offline"` ↔ `0`). Emits a deprecation warning.  |

For the boolean toggles (`COMET_EVAL_LOG_IMAGE_PREDICTIONS` and `COMET_EVAL_LOG_CONFUSION_MATRIX`), the values `1`, `true`, `yes`, `on`, `y`, and `t` are parsed as `True` (case-insensitive). Any other value is `False`.

### Logging Image Predictions

You can control the number of image predictions that Comet logs during your experiments. By default, Comet logs 100 image predictions from the validation set. However, you can change this number to better suit your requirements. For example, to log 200 image predictions, use the following code:

```python
import os

os.environ["COMET_MAX_IMAGE_PREDICTIONS"] = "200"
```

To disable image prediction logging entirely (for example, to reduce upload volume on slow connections), set `COMET_EVAL_LOG_IMAGE_PREDICTIONS` to `"false"`:

```python
import os

os.environ["COMET_EVAL_LOG_IMAGE_PREDICTIONS"] = "false"
```

### Batch Logging Interval

Comet allows you to specify how often batches of image predictions are logged. The `COMET_EVAL_BATCH_LOGGING_INTERVAL` environment variable controls this frequency. The default setting is 1, which logs predictions from every validation batch. You can adjust this value to log predictions at a different interval. For instance, setting it to 4 will log predictions from every fourth batch.

```python
import os

os.environ["COMET_EVAL_BATCH_LOGGING_INTERVAL"] = "4"
```

### Disabling Confusion Matrix Logging

In some cases, you may not want to log the confusion matrix from your validation set after every [epoch](https://www.ultralytics.com/glossary/epoch). You can disable this feature by setting the `COMET_EVAL_LOG_CONFUSION_MATRIX` environment variable to "false." The confusion matrix will only be logged once, after the training is completed.

```python
import os

os.environ["COMET_EVAL_LOG_CONFUSION_MATRIX"] = "false"
```

### Online and Offline Mode

By default, Comet runs in online mode and streams experiment data to the Comet servers. If you need to train without internet access, set `COMET_START_ONLINE=0` before training starts. Experiment data is saved locally and can be uploaded later with the [`comet upload`](https://www.comet.com/docs/v2/api-and-sdk/command-line/reference/) CLI.

```python
import os

os.environ["COMET_START_ONLINE"] = "0"  # 1 (default) = online, 0 = offline
```

!!! note "`COMET_MODE` is deprecated"

    Earlier versions used `COMET_MODE="offline"` for this purpose. The variable is still honored for backward compatibility but emits a deprecation warning. Use `COMET_START_ONLINE` going forward.

### Project Name

By default, the Comet callback passes the YOLO `project` training argument to Comet (or `None` when the argument is unset, in which case Comet uses your workspace default). Override this with `COMET_PROJECT_NAME` to send all experiments to a specific Comet workspace project regardless of the YOLO training argument:

```python
import os

os.environ["COMET_PROJECT_NAME"] = "my-yolo26-experiments"
```

### Model Artifact Name

`COMET_MODEL_NAME` sets the name Comet registers for the logged model artifact (defaults to `Ultralytics`). Use it to differentiate model variants in a shared workspace:

```python
import os

os.environ["COMET_MODEL_NAME"] = "yolo26n-coco128"
```

### Confidence Score Scaling

Detection confidence scores are emitted in the `[0, 1]` range, but the Comet UI displays them on a percentage scale by default. The callback multiplies each score by `COMET_MAX_CONFIDENCE_SCORE` (default `100.0`) before logging. Adjust this if you prefer raw probabilities or a different scale:

```python
import os

os.environ["COMET_MAX_CONFIDENCE_SCORE"] = "1.0"  # log raw [0, 1] scores
```

## Summary

This guide has walked you through integrating Comet with Ultralytics' YOLO26. From installation to customization, you've learned to streamline experiment management, gain real-time insights, and adapt logging to your project's needs.

Explore [Comet's official YOLOv8 integration documentation](https://www.comet.com/docs/v2/integrations/third-party-tools/yolov8/), which also applies to YOLO26 projects.

Furthermore, if you're looking to dive deeper into the practical applications of YOLO26, specifically for [image segmentation](https://www.ultralytics.com/glossary/image-segmentation) tasks, this detailed guide on [fine-tuning YOLO26 with Comet](https://www.comet.com/site/blog/fine-tuning-yolov8-for-image-segmentation-with-comet/) offers valuable insights and step-by-step instructions to enhance your model's performance.

Additionally, to explore other exciting integrations with Ultralytics, check out the [integration guide page](../integrations/index.md), which offers a wealth of resources and information.

## FAQ

### How do I integrate Comet with Ultralytics YOLO26 for training?

To integrate Comet with Ultralytics YOLO26, follow these steps:

1. **Install the required packages**:

    ```bash
    pip install ultralytics comet_ml torch torchvision
    ```

2. **Set up your Comet API Key**:

    ```bash
    export COMET_API_KEY=YOUR_API_KEY
    ```

3. **Initialize your Comet project in your Python code**:

    ```python
    import comet_ml

    comet_ml.login(project_name="comet-example-yolo26-coco128")
    ```

4. **Train your YOLO26 model and log metrics**:

    ```python
    from ultralytics import YOLO

    model = YOLO("yolo26n.pt")
    results = model.train(
        data="coco8.yaml",
        project="comet-example-yolo26-coco128",
        batch=32,
        save_period=1,
        save_json=True,
        epochs=3,
    )
    ```

For more detailed instructions, refer to the [Comet configuration section](#configuring-comet).

### What are the benefits of using Comet with YOLO26?

By integrating Ultralytics YOLO26 with Comet, you can:

- **Monitor real-time insights**: Get instant feedback on your training results, allowing for quick adjustments.
- **Log extensive metrics**: Automatically capture essential metrics such as mAP, loss, hyperparameters, and model checkpoints.
- **Track experiments offline**: Log your training runs locally when internet access is unavailable.
- **Compare different training runs**: Use the interactive Comet dashboard to analyze and compare multiple experiments.

By leveraging these features, you can optimize your machine learning workflows for better performance and reproducibility. For more information, visit the [Comet integration guide](../integrations/index.md).

### How do I customize the logging behavior of Comet during YOLO26 training?

Comet allows for extensive customization of its logging behavior using environment variables:

- **Change the number of image predictions logged**:

    ```python
    import os

    os.environ["COMET_MAX_IMAGE_PREDICTIONS"] = "200"
    ```

- **Adjust batch logging interval**:

    ```python
    import os

    os.environ["COMET_EVAL_BATCH_LOGGING_INTERVAL"] = "4"
    ```

- **Disable confusion matrix logging**:

    ```python
    import os

    os.environ["COMET_EVAL_LOG_CONFUSION_MATRIX"] = "false"
    ```

- **Set the Comet project name**:

    ```python
    import os

    os.environ["COMET_PROJECT_NAME"] = "my-yolo26-experiments"
    ```

- **Set the logged model artifact name**:

    ```python
    import os

    os.environ["COMET_MODEL_NAME"] = "yolo26n-coco128"
    ```

See the [Customizing Comet Logging](#customizing-comet-logging) section for the full list, including image prediction toggles, confidence score scaling, and online/offline mode.

### How do I view detailed metrics and visualizations of my YOLO26 training on Comet?

Once your YOLO26 model starts training, you can access a wide range of metrics and visualizations on the Comet dashboard. Key features include:

- **Experiment Panels**: View different runs and their metrics, including segment mask loss, class loss, and mean average [precision](https://www.ultralytics.com/glossary/precision).
- **Metrics**: Examine metrics in tabular format for detailed analysis.
- **Interactive Confusion Matrix**: Assess classification accuracy with an interactive confusion matrix.
- **System Metrics**: Monitor GPU and CPU utilization, memory usage, and other system metrics.

For a detailed overview of these features, visit the [Understanding Your Model's Performance with Comet Visualizations](#understanding-your-models-performance-with-comet-visualizations) section.

### Can I use Comet for offline logging when training YOLO26 models?

Yes. Set `COMET_START_ONLINE=0` before training starts to log locally:

```python
import os

os.environ["COMET_START_ONLINE"] = "0"
```

Experiment data is saved on disk and can be uploaded to Comet later with the [`comet upload`](https://www.comet.com/docs/v2/api-and-sdk/command-line/reference/) CLI when connectivity is available. The earlier `COMET_MODE="offline"` variable still works but emits a deprecation warning. For more details, see the [Online and Offline Mode](#online-and-offline-mode) section.
