---
title: utils.callbacks.platform API Reference
description: Platform callback functions for console logging during YOLO11 training lifecycle events.
keywords: platform callbacks, training callbacks, console logging, YOLO11 training, lifecycle events, Ultralytics
---

# Reference for `ultralytics/utils/callbacks/platform.py`

!!! success "Improvements"

    This page is sourced from [https://github.com/ultralytics/ultralytics/blob/main/ultralytics/utils/callbacks/platform.py](https://github.com/ultralytics/ultralytics/blob/main/ultralytics/utils/callbacks/platform.py). Have an improvement or example to add? Open a [Pull Request](https://docs.ultralytics.com/help/contributing) — thank you! 🙏

<br>

## ::: ultralytics.utils.callbacks.platform.slugify

<br><br><hr><br>

## ::: ultralytics.utils.callbacks.platform._interp_plot

<br><br><hr><br>

## ::: ultralytics.utils.callbacks.platform._validation_payload

<br><br><hr><br>

## ::: ultralytics.utils.callbacks.platform._sanitize_json_value

<br><br><hr><br>

## ::: ultralytics.utils.callbacks.platform._send

<br><br><hr><br>

## ::: ultralytics.utils.callbacks.platform._handle_control_response

<br><br><hr><br>

## ::: ultralytics.utils.callbacks.platform._upload_model

<br><br><hr><br>

## ::: ultralytics.utils.callbacks.platform._get_environment_info

<br><br><hr><br>

## ::: ultralytics.utils.callbacks.platform._get_project_name

<br><br><hr><br>

## ::: ultralytics.utils.callbacks.platform.on_pretrain_routine_start

<br><br><hr><br>

## ::: ultralytics.utils.callbacks.platform.on_pretrain_routine_end

<br><br><hr><br>

## ::: ultralytics.utils.callbacks.platform.on_fit_epoch_end

<br><br><hr><br>

## ::: ultralytics.utils.callbacks.platform.on_model_save

<br><br><hr><br>

## ::: ultralytics.utils.callbacks.platform.on_train_end

<br><br>
